import { Injectable, signal, computed } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PokemonService {

  kanto = signal([
    { name: 'Pikachu', type: 'Electric', item: 'Light Ball', desc: 'Electric mouse Pokemon' },
    { name: 'Charizard', type: 'Fire/Flying', item: 'Charcoal', desc: 'Flame Pokemon' },
    { name: 'Bulbasaur', type: 'Grass/Poison type', item: 'Bulb', desc: 'Starter Pokémon that uses the bulb on its back to store nutrients and photosynthesize' },
    { name: 'Ivysaur', type: 'Grass/Poison', item: 'Grass', desc: 'Evolution of Bulbasaur' },
    { name: 'Mewtwo', type: 'Psychic', item: 'Hand', desc: 'A powerful, engineered Pokémon' },
    { name: 'Mew', type: 'Psychic', item: 'Psychic', desc: 'A rare, mythical Pokémon' }
  ]);

  johto = signal([
    { name: 'Typhlosion', type: 'Fire', item: 'Charcoal', desc: 'Volcano Pokemon' },
    { name: 'Ampharos', type: 'Electric', item: 'Magnet', desc: 'Light Pokemon' },
    { name: 'Chikorita', type: 'Grass', item: 'Large Leaf', desc: 'A small, light-green dinosaur-like Pokémon with a large leaf on its head and a necklace of small buds.' },
    { name: 'Cyndaquil', type: 'Fire', item: 'Charcoal', desc: 'A shy, mouse-like Pokémon that ignites flames on its back when intimidated or preparing to fight.' },
    { name: 'Totodile', type: 'Water', item: 'Water', desc: 'A small, bipedal crocodile Pokémon with a playful, yet dangerous nature.' },
    { name: 'Togepi', type: 'Later Fairy', item: 'Fairy', desc: ' A small, cream-colored baby Pokémon that remains in a cracked eggshell.' }
  ]);

  hoenn = signal([
    { name: 'Blaziken', type: 'Fire/Fighting', item: 'Focus Band', desc: 'Blaze Pokemon' },
    { name: 'Gardevoir', type: 'Psychic/Fairy', item: 'Twisted Spoon', desc: 'Embrace Pokemon' },
    { name: 'Treecko', type: 'Grass', item: 'Wood', desc: 'The Wood Gecko Pokémon. Known for being agile and living in trees.' },
    { name: 'Grovyle', type: 'Grass', item: 'Wood', desc: 'Evolves from Treecko. A fast, middle-evolution capable of high Special Attack.' },
    { name: 'Sceptile', type: 'Grass', item: 'Wood', desc: 'The final form, capable of Mega Evolution.' },
    { name: 'Marshtomp', type: 'Water/Ground', item: 'Rock', desc: 'Evolves from Mudkip.' }
  ]);

  items = signal([
    { name: 'Potion', price: 300 },
    { name: 'Super Potion', price: 700 },
    { name: 'Hyper Potion', price: 1200 },
    { name: 'Revive', price: 1500 },
    { name: 'Antidote', price: 100 },
    { name: 'Paralyze Heal', price: 200 },
    { name: 'Burn Heal', price: 250 },
    { name: 'Ice Heal', price: 250 },
    { name: 'Full Heal', price: 600 },
    { name: 'Poke Ball', price: 200 }
  ]);

  cart = signal<any[]>([]);

  addToCart(item:any){
    this.cart.update(c => [...c, item]);
  }

  total = computed(() =>
    this.cart().reduce((sum, item) => sum + item.price, 0)
  );

}